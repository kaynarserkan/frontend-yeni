export type KanbanColumn<T> = {
  key: string
  title: string
  items: T[]
}
