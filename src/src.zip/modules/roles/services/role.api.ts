import { api } from "@/core/http/api.client";

export type RolePermission = {
  id: number;
  name: string;
  guard_name?: string;
};

export type Role = {
  id: number;
  name: string;
  title?: string | null;
  permissions: RolePermission[];
};

export type RoleUpsertPayload = {
  name: string;
  title?: string | null;
};

export const listRoles = async (): Promise<Role[]> => {
  const res = await api.get("/api/roles");
  return res.data?.data ?? [];
};

export const getRole = async (id: number | string): Promise<Role> => {
  const res = await api.get(`/api/roles/${id}`);
  // bazı endpointler {id, name, ...} dönebiliyor
  return (res.data?.data ?? res.data) as Role;
};

export const createRole = async (payload: RoleUpsertPayload): Promise<Role> => {
  const res = await api.post("/api/roles", payload);
  return (res.data?.data ?? res.data) as Role;
};

export const updateRole = async (
  id: number | string,
  payload: RoleUpsertPayload,
): Promise<Role> => {
  const res = await api.put(`/api/roles/${id}`, payload);
  return (res.data?.data ?? res.data) as Role;
};

export const deleteRole = async (id: number | string): Promise<Role> => {
  const res = await api.delete(`/api/roles/${id}`);
  return (res.data?.data ?? res.data) as Role;
};

export const syncRolePermissions = async (
  id: number | string,
  permissions: string[],
): Promise<Role> => {
  const res = await api.post(`/api/roles/${id}/permissions/sync`, {
    permissions,
  });
  return (res.data?.data ?? res.data) as Role;
};
